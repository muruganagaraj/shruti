import { Component, OnInit } from '@angular/core';
import { AddGstComponent } from 'app/add-gst/add-gst.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-gst-detail',
  templateUrl: './gst-detail.component.html',
  styleUrls: ['./gst-detail.component.css']
})
export class GstDetailComponent implements OnInit {

  animal: string;
  name: string;

  constructor(public dialog: MatDialog) { }
  ngOnInit() {
    this.animal = "Lion";
    this.name = "Shruthi";
  }
  openDialog(): void {
    const dialogRef = this.dialog.open(AddGstComponent, {
      height: "auto",
      width: "auto",
      data: { name: this.name, animal: this.animal }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
    });
  }
}
